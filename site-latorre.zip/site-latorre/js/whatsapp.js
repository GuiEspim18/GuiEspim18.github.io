/* . Arquivo para envio de mensagens no whastapp do dono do site. */
/* .............................................................. */

/* ============================================================= */
/* |........................Global Vars........................| */
/* ============================================================= */

let resButton = document.querySelector("button#res_button");
let resDate = document.querySelector("input#datepicker");
let resTime = document.querySelector("input#res_time");
let resSelect = document.querySelector("select#res_select");
let linkWhats = document.querySelector("a#res_link");

/* ============================================================= */
/* |.........................Script JS.........................| */
/* ============================================================= */

linkWhats.addEventListener("click", ()=>{
    let date = new Date();
    let hours = date.getHours();
    let mes;
    if(hours>=0 && hours<=12){
        mes = "Bom dia";
    }else if(hours>=13 && hours<=18){
        mes = "Boa tarde";
    }else{
        mes = "Boa noite";
    }
    let message = `${mes}, gostaria de fazer um orçamento de festa para o dia ${resDate.value}, as ${resTime.value}, para ${resSelect.value}.`;
    linkWhats.setAttribute("href", `https://api.whatsapp.com/send?phone=+5511983361509&text=${message}`);
});
